<template>
  <div>
     
  </div>
</template>

<script>
import { formatTime } from '@/utils/index'

export default {

  data () {
    return {
     
    }
  },

  created () {
    let logs
    if (mpvuePlatform === 'my') {
      logs = mpvue.getStorageSync({key: 'logs'}).data || []
    } else {
      logs = mpvue.getStorageSync('logs') || []
    }
    this.logs = logs.map(log => formatTime(new Date(log)))
  }
}
</script>

<style>

</style>
