export default [
    {
        type_name: "玄幻",
        type_link: "https://www.2952.cc/xuanhuan/"
    },{
        type_name: "修真",
        type_link: "https://www.2952.cc/xiuzhen/"
    },{
        type_name: "都市",
        type_link: "https://www.2952.cc/dushi/"
    },{
        type_name: "历史",
        type_link: "https://www.2952.cc/chuanyue/"
    },{
        type_name: "网游",
        type_link: "https://www.2952.cc/wangyou/"
    },{
        type_name: "科幻",
        type_link: "https://www.2952.cc/kehuan/"
    },{
        type_name: "言情",
        type_link: "https://www.2952.cc/yanqing/"
    },{
        type_name: "推理",
        type_link: "https://www.2952.cc/tuili/"
    },
]
